int mostrar;
int pulsos;